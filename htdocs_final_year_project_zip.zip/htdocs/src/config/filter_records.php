<?php

//array with key value pairs for filtering records

$filter_records = [
    'record_number' => 'Record Number',
    'record_type' => 'Record Type',
    'blood_group' => 'Blood Group',
    'bank_id' => 'Bank ID',
    'note' => 'Note',
    'date' => 'Date'
];

?>

