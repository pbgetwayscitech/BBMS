<?php

//gedners array with key value pairs

$genders = [
    'male' => 'Male',
    'female' => 'Female',
];


?>

