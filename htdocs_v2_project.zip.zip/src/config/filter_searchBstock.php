<?php

//array with key value pairs for filtering blood stock

$filter_searchBstock = [
    "all" => "All",
    "stock_id" => "Stock ID",
    "donor_id" => "Donor ID",
    "bank_id" => "Bank ID",
    "donation_date" => "Donation Date",
    "blood_group" => "Blood Group",
    "expiry_date" => "Expiry Date",
    "note" => "Note",
    "stock_status" => "Stock Status",
    "stock_status_date" => "Stock Status Date"
];

?>

