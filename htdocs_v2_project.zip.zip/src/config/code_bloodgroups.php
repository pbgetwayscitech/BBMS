<?php

//blood groups array with key value pairs

$blood_groups = [
    'ap' => 'A+',
    'a' => 'A-',
    'bp' => 'B+',
    'b' => 'B-',
    'op' => 'O+',
    'o' => 'O-',
    'abp' => 'AB+',
    'ab' => 'AB-',
];

?>

